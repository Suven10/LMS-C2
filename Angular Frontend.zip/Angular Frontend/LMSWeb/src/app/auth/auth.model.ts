export class Profile {
    firstName:string;
    username: string;
    lastName:string;
    gender: string;
    dob : string;
    address: string;
    password: string;
    email:string;
    phone:string;
    ssn:string;
    isStudent:boolean;
    isInstructor:boolean;
    constructor() {
    }
}