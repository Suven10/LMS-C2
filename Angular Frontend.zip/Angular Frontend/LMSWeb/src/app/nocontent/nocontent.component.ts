import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nocontent',
  templateUrl: './nocontent.component.html',
  styleUrls: ['./nocontent.component.css']
})
export class NocontentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
