<?php

Class Subscription{
	
	public $guCourseId;
	public $guProfileId;
	public $guEnrollId;
	public $coveredModules;
	public $subscribedDate;
	public $desc;
	public $createdDate;
}

?>