<?php

Class Profile{
	
	public $guProfileId;
	
	public $phone;
	public $email;
	public $status;
	public $address;
	public $firstName;
	public $lastName;
	public $ssn;	
	public $dob;
	public $gender;
	public $createdDate;
	public $isStudent;
	public $isInstructor;

}

?>