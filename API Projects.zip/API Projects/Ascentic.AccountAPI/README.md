http://localhost:8012/Ascentic/API/src/Ascentic.AccountAPI/accounts/?skip=0&take=100&order=desc
http://localhost:8012/Ascentic/API/src/Ascentic.AccountAPI/account/2849DA68-6727-44D3-12DC-3DDDEF4DD5A2

http://localhost:8012/Ascentic/API/src/Ascentic.AccountAPI/account
{
	"username": "Suvethan",
	"password": "",
	"guProfileId": ""
}

headers - content-type : application/json

