<?php

Class Account{
	
	public $guProfileId;
	public $guAccountId;
	public $username;
	public $password;
	public $createdDate;

}

?>