<?php

Class Course{
	
	public $guCourseId;
	public $guCatId;
	public $name;
	public $code;
	public $type;
	public $filePath;
	public $totModules;
	public $desc;
	public $createdDate;
	public $imgPath;
}


Class Category{
	public $guCatId;
	public $name;
	public $code;
	public $desc;
	public $createdDate;
}

?>