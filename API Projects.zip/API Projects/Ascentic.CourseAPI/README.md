http://localhost:8012/Ascentic/API/src/Ascentic.ProfileAPI/profiles/?skip=0&take=100&order=desc
http://localhost:8012/Ascentic/API/src/Ascentic.ProfileAPI/profile/2849DA68-6727-44D3-12DC-3DDDEF4DD5A2

http://localhost:8012/Ascentic/API/src/Ascentic.ProfileAPI/profile
{
	"gender": "Male",
	"dob": "1992-10-10",
	"email": "suvethann10@gmail.com",
	"address": "Wellawatte,Colombo-06",
	"firstName": "Suvethan",
	"lastName": "Nantha",
	"phone": "94777612091",
	"ssn":"902840474v"
}

headers - content-type : application/json

